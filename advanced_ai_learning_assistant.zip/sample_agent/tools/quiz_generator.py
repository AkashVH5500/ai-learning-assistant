# quiz_generator.py - simple quiz generation from context; for demo purposes
import random
class QuizAgent:
    def __init__(self, memory_bank=None):
        self.memory_bank = memory_bank

    def generate_quiz(self, query, n=5):
        # For demo: produce n synthetic questions referencing the query
        questions = []
        for i in range(n):
            questions.append({
                'id': f'q{i}',
                'question': f'Question {i+1} about {query}',
                'choices': ['A','B','C','D'],
                'answer': 'A'
            })
        return {'questions': questions, 'meta': {'query': query}}
